ALTER TABLE tblfilter ADD fldmaske text
ALTER TABLE tblfilter ADD fldName text