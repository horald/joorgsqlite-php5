INSERT INTO tblmenu_liste (fldid_parent,fldglyphicon,fldlink,fldbez,fldview) VALUES(0,'glyphicon-calendar','classes/calendar.php','Kalender','J');
