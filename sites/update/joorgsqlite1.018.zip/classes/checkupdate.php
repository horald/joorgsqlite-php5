<?php
include("bootstrapfunc.php");
bootstraphead();
bootstrapbegin("Joorgportal - Checkupdate<br>");
echo "<a href='../index.php' class='btn btn-primary btn-sm active' role='button'>Menü</a> "; 
echo "<a href='about.php' class='btn btn-primary btn-sm active' role='button'>zurück</a> "; 

$getvers=$_GET['getvers'];
if ($getvers=="") {
  echo "<a id='idVersion' href='#' class='btn btn-primary btn-sm active' role='button'>GetVersion</a><br> "; 

  echo "<script>"; 
  echo "  meinHandler('idVersion','click',vers_anfordern); ";
  echo "</script>";
  $getvers=$_POST['versnr'];
} else {
  echo "<br>";
} 

$string = file_get_contents("../version.json");
$json_a = json_decode($string, true);
$locvers=$json_a['versnr'];

if ($getvers<>"") {
  if ($getvers>$locvers) {
  	 echo "<br>";
    echo "<a href='https://github.com/horald/joorgsqlite/raw/gh-pages/sites/update/joorgsqlite".$getvers.".tar.gz' class='btn btn-primary btn-sm active' role='button'>Download Update Version ".$getvers."</a><br> "; 
    echo "<a href='unzipupdate.php?versnr=".$getvers."' class='btn btn-primary btn-sm active' role='button'>Unzip Update Version ".$getvers."</a><br> "; 
  } else {
    echo "<div class='alert alert-success'>";
  	 echo "Sie haben die aktuelle Version ".$getvers;
  	 echo "</div>";
  }
}

bootstrapend();
?>