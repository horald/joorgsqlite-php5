<?php
$conthtml = file_get_contents("einleitung.html",true);
echo $conthtml;
?>